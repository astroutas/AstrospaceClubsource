# Astrospace Club — Cloudflare deployment

This project is configured for Cloudflare Workers with D1.

## D1 configuration

- Binding: `DB`
- Database name: `astroutas`
- Database ID: `3eb589a8-d7f6-46bd-9bfc-c28db0951983`

## First deployment

Use Node.js 22.13 or newer.

```bash
npm install
npx wrangler login
npm run db:migrate
npm run deploy
```

## Admin access

The app grants admin access when the member phone matches the `ADMIN_PHONE` Worker variable.
After the Worker is created, set `ADMIN_PHONE` in Cloudflare Dashboard under the Worker's Settings > Variables and Secrets.

The example value currently present in `.env.example` is only for local/reference use and is not automatically uploaded to Cloudflare.

## Custom domain

After deployment, add your domain from the Worker dashboard under Domains & Routes > Add > Custom Domain.
